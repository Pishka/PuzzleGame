from game.core.puzzle_game import PuzzleGame

if __name__ == '__main__':
    game = PuzzleGame()
    game.run_game()
    # game.run_game(x_size=2, y_size=3)