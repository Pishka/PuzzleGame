from enum import Enum


class PuzzleDifficultyEnum(Enum):

    Easy = 10

    Medium = 50

    Hard = 100